<?php

session_start();

if(!empty($_POST)){
if(isset($_POST["idsujet"], $_POST["idredacteur"], $_POST["textereponse"])
	&& !empty($_POST["idsujet"]) && !empty ($_POST["idredacteur"]) && !empty ($_POST["textereponse"])
	
	){
		require_once('connexionbdd.php');
		
		$req="INSERT INTO `reponse`(`idsujet`,`idredacteur`, `textereponse`) VALUES (:idsujet, :idredacteur, :textereponse)";
		
		$query=$objPdo->prepare($req);
		
		$query->bindValue('idsujet', $_POST['idsujet'], PDO::PARAM_INT);
		$query->bindValue('idredacteur', $_POST['idredacteur'], PDO::PARAM_INT);
		$query->bindValue('textereponse', $_POST['textereponse'], PDO::PARAM_STR);
		
		if($query->execute()){
			die("La réponse a été envoyée avec succès !");
		}
		
		if(!$query->execute()){
			die("Une erreur est survenue !");
		}
		
	}else{
			die("Le formulaire est incomplet !");
	}
}		

?>

<!DOCTYPE html>
	<html>
	<link rel="stylesheet" href="css/style_connexion_site.css">
	<h1>Ajout d'une nouvelle réponse</h1>
	<title>Ajout réponse</title>

		<form method="post">
			
			<div>
				<label for="idsujet">Numéro :</label>
				<input type="int" name="idsujet">
			</div>
			</br>

			<div>
				<label for="idredacteur">Numéro :</label>
				<input type="int" name="idredacteur">
			</div>
			</br>

			<div>
				<label for="textereponse">Réponse:</label>
				<textarea name="textereponse" id="textereponse"></textarea>
			</div>
			</br>
			<button type="submit">Enregistrer</button>
		</form>

<a href="blog.php"><button type="submit">Annuler</button></a>
</html>