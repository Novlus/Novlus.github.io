<?php

if(!isset($_GET["idsujet"]) || empty($_GET["idsujet"])){
	header("Location: blog.php");
	exit;
													   }

	$idsujet = $_GET["idsujet"];
	$sql = "SELECT * FROM `sujet` WHERE `idsujet` = :idsujet";

	session_start();

	require_once('connexionbdd.php');

	$requete =$objPdo->prepare($sql);
	$requete->bindValue(":idsujet", $idsujet, PDO::PARAM_INT);
	$requete->execute();

	$article = $requete->fetch();

if(!$article){
	http_response_code(404);
	echo "Article inexistant";
	exit;
			 }	

?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
</head>

	<link rel="stylesheet" href="css/mainstyle.css">
	<title><?php echo strip_tags($article["titresujet"]) ?></title>
	
	<h1><?php $titre =strip_tags($article["titresujet"]);?> </h1>

<article>
	
	<h1><?php echo strip_tags($article["titresujet"]) ?></a></h1>
	<p>Publié le <?php echo $article["datesujet"] ?></p>
	<div><?php echo strip_tags($article["textesujet"]) ?></div>
	
</article>
</html>

<?php 
require_once('connexionbdd.php');

$sql = "SELECT * FROM `reponse` ORDER BY `daterep` DESC";

$requete = $objPdo->query($sql);

$reponses = $requete->fetchAll();

?>

<!DOCTYPE html>
<html>
	<h1>Réponses</h1>

	<?php foreach($reponses as $reponse): ?>

<section>
	<article>
		
		<h1><a href="reponse.php?idreponse=<?= $reponse["idreponse"]?>"></a></h1>
		<p>Publié le <?php echo $reponse["daterep"] ?></p>
		<div><?php echo strip_tags($reponse["textereponse"]) ?></div></br></br>
	
		<?php if(isset($_SESSION["utilisateur"])): ?>
		<a href="ajout_reponse.php"><button type="submit" class="ajout_reponse">Ajouter une réponse</button></a>
		<?php endif; ?>
		
	</article>
</section>
</html>
		<?php endforeach;
		
?>
</br></br></br>
	<a href="blog.php"><button type="submit">Retour Accueil</button></a>
	</br></br>
<footer>
	<p>Site réalisé par DI TULLIO Louis et CREMON Damien (Novembre 2021)</p>
</footer>	
<a href = "#" class="retour_haut_page">Retour en haut de la page</a>
</html>