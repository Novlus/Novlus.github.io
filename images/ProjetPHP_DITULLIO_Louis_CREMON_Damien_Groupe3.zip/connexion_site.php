<?php

if(!empty($_POST)){
if(isset($_POST["adressemail"], ($_POST["motdepasse"]))
	&&!empty ($_POST["adressemail"]) && !empty($_POST["motdepasse"])
	
	){
		
		require_once('connexionbdd.php');
		
		$req= "SELECT * FROM `redacteur` WHERE `adressemail` = :adressemail AND `motdepasse` = :motdepasse";
		
		$query=$objPdo->prepare($req);
		
		$query->bindValue(":adressemail", $_POST["adressemail"], PDO::PARAM_STR);	
		$query->bindValue(":motdepasse", $_POST["motdepasse"], PDO::PARAM_STR);
		$query->execute();
		$utilisateur = $query->fetch();
		
		if(!$utilisateur){
			die("L'adresse e-mail, le nom d'utilisateur et/ou le mot de passe est incorrect !");
						 }
		
		if(password_verify($_POST["motdepasse"], $utilisateur ["motdepasse"])){
			die("Le mot de passe est incorrect !");
																			  }
																			  
		session_start();
		
		$_SESSION["utilisateur"] = [
		"idredacteur" => $utilisateur["idredacteur"],
		"nom" => $utilisateur["nom"],
		"prenom" => $utilisateur["prenom"],
		"adressemail" => $utilisateur["adressemail"],
		"motdepasse" => $utilisateur["motdepasse"],
		"pseudo" => $utilisateur["pseudo"]
		];
		
		header("location: profil.php");

		if(!filter_var($_POST["adressemail"], FILTER_VALIDATE_EMAIL)){
			die ("L'adresse e-mail saisie est incorrecte !");
																     }	
			
			if($query->execute()){
			echo("Le compte a été créé avec succès !"); 
								 }
								 
		if(!$query->execute()){
			die("Une erreur est survenue !");
						      }
		
	}else{
			die("Le formulaire est incomplet !");
	}
}		
			
?>

<!DOCTYPE html>
<html>
<link rel="stylesheet" href="css/style_connexion_site.css">
<title>Se connecter</title>
<h1>Se connecter</h1>

		<form method="post">
		
		<div>
			<label for="adressemail">Adresse e-mail :</label>
			<input type="text" name="adressemail">
		</div>

		<div>
			<label for="mdp">Mot de passe :</label>
			<input type="text" name="motdepasse">
			<button type="submit">Connexion</button>
			</div>
			</form>
<a href="blog.php"><button type="submit">Annuler</button></a>		

</html>