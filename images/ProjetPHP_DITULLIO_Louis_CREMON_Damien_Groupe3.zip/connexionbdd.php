<?php
try
{
	$objPdo = new PDO 
			 ('mysql:host=devbdd.iutmetz.univ-lorraine.fr;port=3306;dbname=ditullio4u_ProjetPHP2;charset=utf8','ditullio4u_appli','32010368');
			 //echo "connexion ok<br />\n";
}
catch(Exception $exception)
{
	die($exception->getMessage());
}
?>