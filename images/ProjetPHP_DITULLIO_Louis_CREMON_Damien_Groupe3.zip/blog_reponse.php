<?php 

session_start();

require_once('connexionbdd.php');

$sql = "SELECT * FROM `reponse` ORDER BY `daterep` DESC";

$requete = $objPdo->query($sql);

$reponses = $requete->fetchAll();

?>

<!DOCTYPE html>
<html>
	<h1>Liste des blogs</h1>

	<?php foreach($reponses as $reponse): ?>

<section>
	<article>
		
		<h1><a href="reponse.php?idreponse=<?= $reponse["idreponse"]?>"></a></h1>
		<p>Publié le <?php echo $reponse["daterep"] ?></p>
		<div><?php echo strip_tags($reponse["textereponse"]) ?></div>
	
		<?php if(isset($_SESSION["utilisateur"])): ?>
		<a href="ajout_reponse.php"><button type="submit">Ajouter une nouvelle réponse</button></a>
		<?php endif; ?>
		
	</article>
</section>
</html>
		<?php endforeach;

?>

<!DOCTYPE html>
<html>
<title>Réponses </title>
	
	<head>
		<meta charset="utf-8">
	</head>

	<body>
	</br></br>

	<ul>
		
		<?php if(!isset($_SESSION["utilisateur"])): ?>
			<li><a href="connexion_site.php"><button type="submit">Se connecter</button></a></li>
			<li><a href="creation_compte.php"><button type="submit">Se créer un compte</button></a></li>
		<?php else: ?>

		<p>Bonjour <?= $_SESSION["utilisateur"]["pseudo"]?> !</p>
		
			<li><a href="ajout_blog.php"><button type="submit">Ajouter un nouveau blog</button></a></li>
			<li><a href="deconnexion.php"/><button type="submit">Se déconnecter</button></a></li>
		<?php endif; ?>
	
	</ul>
	</body>
</html>	