//NON ABOUTI//
<?php 

session_start();
?>

<?php
if(isset($_GET["idredacteur"]))
{
	$idredacteur = $_GET["idredacteur"];
	if(!empty($idredacteur) && is_numeric($idredacteur))
	{
		include("connexionbdd.php");
		$query = "DELETE FROM redacteur WHERE idredacteur=$idredacteur";
		$query = $objPdo->query($query);
	}else{
			die("Le compte a bien été supprimé !");
	}
	}
?>

<?php

if(!isset($_GET["idredacteur"]) || empty($_GET["idredacteur"])){
	header("Location: blog.php");
	exit;
													   }
	$idredacteur = $_GET["idredacteur"];
	$sql = "SELECT * FROM `redacteur` WHERE `idredacteur` = :idredacteur";

	require_once('connexionbdd.php');

	$requete =$objPdo->prepare($sql);
	$requete->bindValue(":idredacteur", $idredacteur, PDO::PARAM_INT);
	$requete->execute();

	$idredacteur = $requete->fetch();

if(!$idredacteur){
	http_response_code(404);
	echo "Utilisateur inexistant";
	exit;
			 }	

?>