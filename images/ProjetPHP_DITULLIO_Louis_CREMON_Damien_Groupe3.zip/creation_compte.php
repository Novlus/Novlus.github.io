<?php
if(!empty($_POST)){
if(isset($_POST["nom"], $_POST["prenom"], $_POST["adressemail"], $_POST["motdepasse"], $_POST["pseudo"])
	&&!empty($_POST["nom"]) && !empty ($_POST["prenom"]) && !empty ($_POST["adressemail"]) && !empty($_POST["motdepasse"]) && !empty($_POST["pseudo"])
	){
		require_once('connexionbdd.php');
		
		$req="INSERT INTO `redacteur`(`nom`,`prenom`,`adressemail`,`motdepasse`,`pseudo`) VALUES (:nom, :prenom, :adressemail, :motdepasse, :pseudo)";
		
		$query=$objPdo->prepare($req);
		
		$query->bindValue('nom', $_POST['nom'], PDO::PARAM_STR);
		$query->bindValue('prenom', $_POST['prenom'], PDO::PARAM_STR);
		$query->bindValue('adressemail', $_POST['adressemail'], PDO::PARAM_STR);
		$query->bindValue('motdepasse', $_POST['motdepasse'], PDO::PARAM_STR);
		$query->bindValue('pseudo', $_POST['pseudo'], PDO::PARAM_STR);	

		session_start();
			
			$_SESSION["utilisateur"] = [
			"idredacteur" => $utilisateur["idredacteur"],
			"nom" => $_POST["nom"],
			"prenom" => $_POST["prenom"],
			"adressemail" => $_POST["adressemail"],
			"motdepasse" => $utilisateur["motdepasse"],
			"pseudo" => $_POST["pseudo"]
									   ];
									   
		header("location: profil.php");	

		if($query->execute()){
			echo("Le compte a été créé avec succès !"); 
		}	
		if(!$query->execute()){
			die("Une erreur est survenue !");
		}
		
	}else{
			die("Le formulaire est incomplet !");
	}
}		
			

?>
<!DOCTYPE html>
<html>
<link rel="stylesheet" href="css/style_connexion_site.css">
<h1>Création d'un nouveau compte</h1>
	<title>Se créer un compte</title>

	<form method="post">
		
		<div>
			<label for="nom">Nom :</label>
			<input type="text" name="nom">
		</div>

		<div>
			<label for="prenom">Prénom : </label>
			<input type="text" name="prenom">
		</div>

		<div>
			<label for="adressemail">Adresse e-mail :</label>
			<input type="text" name="adressemail">
		</div>

		<div>
			<label for="mdp">Mot de passe :</label>
			<input type="text" name="motdepasse">
		</div>

		<div>
			<label for="pseudo">Pseudo :</label>
			<input type="text" name="pseudo">
		</div>

		<button type="submit">Créer</button>
	</form>

<a href="blog.php"><button type="submit">Annuler</button></a>
</html>