<?php
if(isset($_GET["idsujet"]))
{
	$id = $_GET["idsujet"];
	if(!empty($id) && is_numeric($id))
	{
		include("connexionbdd.php");
		$query = "DELETE FROM sujet WHERE idsujet=$id";
		$query = $objPdo->query($query);
		header("Location:blog.php");
	}
}
?>
