<?php 

session_start();

require_once('connexionbdd.php');

$sql = "SELECT * FROM `sujet` ORDER BY `datesujet` DESC";

$requete = $objPdo->query($sql);

$articles = $requete->fetchAll();

$titre ="Liste des articles du blog";

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport">
	<title>Page Accueil - Blogs</title>
	<link rel="stylesheet" href="css/mainstyle.css">
</head>
<body>
	<nav>
	<h1>Liste des blogs</h1>
	<div class="Onglets">		
		<?php if(!isset($_SESSION["utilisateur"])): ?>
			<a href="connexion_site.php" class="connexion_site"><button type="submit">Se connecter</button></a>
			<a href="creation_compte.php" class="creation_compte"><button type="submit">Se créer un compte</button></a>
		<?php else: ?>

		<p>Bonjour <?= $_SESSION["utilisateur"]["pseudo"]?> !</p>
		
			<a href="ajout_blog.php" class="ajout_blog"><button type="submit">Ajouter un blog</button></a>
			<a href="profil.php" class="profil"><button type="submit">Profil</button></a>			
			<a href="deconnexion.php" class="deconnexion"><button type="submit">Se déconnecter</button></a>
		<?php endif; ?>
</div>
</nav>
	<?php foreach($articles as $article): ?>
<section>
	<article>
		
		<h1><a href="article.php?idsujet=<?= $article["idsujet"]?>"><?php echo strip_tags($article["titresujet"]) ?></a></h1>
		<p>Publié le <?php echo $article["datesujet"] ?></p>
		<div><?php echo strip_tags($article["textesujet"]) ?></div>
		</br>
		<?php if(isset($_SESSION["utilisateur"])): ?>
		<a href="supprimer_sujet.php?idsujet=<?=$article["idsujet"]?>"class="supprimer_sujet"><button type="submit">Supprimer le sujet</button></a>
		<a href="ajout_reponse.php" class="ajout_reponse"><button type="submit">Ajouter une réponse</button></a>
		</br></br></br>
		<?php endif; ?>
		
	</article>
</section>

		<?php endforeach;

?>
</body>
</br></br>
<footer>
	<p>Site réalisé par DI TULLIO Louis et CREMON Damien (Novembre 2021)</p>
</footer>
<a href = "#" class="retour_haut_page">Retour en haut de la page</a>
</html>	