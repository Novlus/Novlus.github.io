<?php 

session_start();

require_once('connexionbdd.php');

$sql = "SELECT * FROM `redacteur`";

$requete = $objPdo->query($sql);

$idredacteur = $requete->fetchAll();
?>



<!DOCTYPE html>
<html>
	<link rel="stylesheet" href="css/mainstyle.css">
<title>Profil</title>
	
	<h1>Profil de <?= $_SESSION["utilisateur"]["pseudo"]?> </h1>
	<p>Identité : <?= $_SESSION["utilisateur"]["nom"] ?> <?= $_SESSION["utilisateur"]["prenom"] ?></p>
	<p>Pseudo : <?= $_SESSION["utilisateur"]["pseudo"]?></p>
	<p>Email : <?= $_SESSION["utilisateur"]["adressemail"]?></p>

<a href="blog.php"><button type="submit">Retour Accueil</button></a>
<a href="supprimer_Profil.php"><button type="submit">Supprimer le profil</button></a>

</html>