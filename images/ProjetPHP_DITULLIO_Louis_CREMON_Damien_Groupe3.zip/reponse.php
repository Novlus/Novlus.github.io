<?php

if(!isset($_GET["idreponse"]) || empty($_GET["idreponse"])){
	header("Location: blogs_reponse.php");
	exit;
													   }

	$idreponse = $_GET["idreponse"];
	$sql = "SELECT * FROM `reponse` WHERE `idreponse` = :idreponse";

	session_start();
	
	require_once('connexionbdd.php');

	$requete =$objPdo->prepare($sql);
	$requete->bindValue(":idreponse", $idreponse, PDO::PARAM_INT);
	$requete->execute();

	$reponse = $requete->fetch();

if(!$reponse){
	http_response_code(404);
	echo "Réponse inexistante";
	exit;
			 }	

?>

<!DOCTYPE html>
<html>
	<title><?php echo strip_tags($reponse["textereponse"]) ?></title>
	
	<h1><?php $titre =strip_tags($reponse["textereponse"]);?> </h1>

<article>
	
	<h1><?php echo strip_tags($reponse["textereponse"]) ?></a></h1>
	<p>Publié le <?php echo $reponse["daterep"] ?></p>
	<div><?php echo strip_tags($reponse["textereponse"]) ?></div>
	
	<a href="blog.php"><button type="submit">Retourner à la page d'accueil</button></a>
</article>
</html>