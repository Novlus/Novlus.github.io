<?php
session_start();

if(!empty($_POST)){
if(isset($_POST["idredacteur"],$_POST["titresujet"], $_POST["textesujet"])
	&&!empty($_POST["idredacteur"]) && !empty($_POST["titresujet"]) && !empty ($_POST["textesujet"]) 
	
	){
		require_once('connexionbdd.php');
		
		$req="INSERT INTO `sujet`(`idredacteur`, `titresujet`,`textesujet`) VALUES (:idredacteur, :titresujet, :textesujet)";
		
		$query=$objPdo->prepare($req);
		
		$query->bindValue('idredacteur', $_POST['idredacteur'], PDO::PARAM_INT);
		$query->bindValue('titresujet', $_POST['titresujet'], PDO::PARAM_STR);
		$query->bindValue('textesujet', $_POST['textesujet'], PDO::PARAM_STR);
		
		if($query->execute()){
			header('Location:blog.php');
		}	
		
		if(!$query->execute()){
			die("Une erreur est survenue !");
		}
		
	}else{
			die("Le formulaire est incomplet !");
	}
}		
			
?>
<!DOCTYPE html>
<html>
<link rel="stylesheet" href="css/style_connexion_site.css">
<h1>Ajout d'un nouveau blog</h1>
	<title>Ajout blog</title>

	<form method="post">
		
		<div>
			<label for="idredacteur">Numéro:</label>
			<input text name="idredacteur">
		</div>
		</br>

		<div>
			<label for="titresujet">Titre du sujet :</label>
			<textarea name="titresujet" id="titresujet"></textarea>
		</div>
		</br>

		<div>
			<label for="textesujet">Texte du sujet :</label>
			<textarea name="textesujet" id="textesujet"></textarea>
		</div>
			</br>
			<button type="submit">Enregistrer</button>
	
	</form>
	
	<a href="blog.php"><button type="submit">Annuler</button></a>
</html>