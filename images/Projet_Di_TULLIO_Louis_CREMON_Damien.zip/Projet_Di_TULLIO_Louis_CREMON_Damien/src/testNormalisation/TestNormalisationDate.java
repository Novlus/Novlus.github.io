package testNormalisation;

import static org.junit.Assert.assertEquals;

import java.time.LocalDate;

import org.junit.Test;

import factory.DAOFactory;
import factory.Persistance;
import modele.metier.Abonnement;
import modele.metier.Client;
import normalisation.NormalisationDoublonClient;

public class TestNormalisationDate 
{
	@Test
	public void NormalisationDateAnnee() throws Exception 
	{
		Abonnement a1 = new Abonnement(LocalDate.parse("2020-12-29"),LocalDate.parse("2019-11-29"),1,1);
		assertEquals(true,normalisation.NormalisationDate.setDateNormalise(a1));
	}
	
	@Test
	public void NormalisationDateAnneeMois() throws Exception 
	{
		Abonnement a1 = new Abonnement(LocalDate.parse("2020-12-29"),LocalDate.parse("2020-11-29"),1,1);
		assertEquals(true,normalisation.NormalisationDate.setDateNormalise(a1));
	}
	
	@Test
	public void NormalisationDateAnneeMoisJour() throws Exception 
	{
		Abonnement a1 = new Abonnement(LocalDate.parse("2020-12-29"),LocalDate.parse("2020-12-28"),1,1);
		assertEquals(true,normalisation.NormalisationDate.setDateNormalise(a1));
	}
}
