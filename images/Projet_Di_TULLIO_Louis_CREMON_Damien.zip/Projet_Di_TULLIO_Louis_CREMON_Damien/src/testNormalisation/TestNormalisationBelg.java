package testNormalisation;

import org.junit.Test;
import static org.junit.Assert.assertEquals;
import modele.metier.Client;
import normalisation.NormalisationPays;

public class TestNormalisationBelg 
{
	@Test
	public void NormalisationBelg() 
	{
		Client cl1 = new Client( "CREMON", "Mathieu", "8 boulevard", "Fauborg", "54000", "Nancy", "belgium");
		assertEquals("Belgique",NormalisationPays.setPaysNormaliseBelg(cl1));
	}
	
	@Test
	public void NormalisationBelg2()
	{
		Client cl1 = new Client( "CREMON", "Mathieu", "8 boulevard", "Fauborg", "54000", "Nancy", "Belgium");
		assertEquals("Belgique",NormalisationPays.setPaysNormaliseBelg(cl1));
	}
}
