package testNormalisation;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import modele.metier.Client;
import modele.metier.Revue;
import normalisation.NormalisationDescription;

public class TestNormalisationDescription 
{
	@Test
	public void normalisationDescription ()
	{
		Revue r1 = new Revue("Koala","aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaajjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeerrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr ppppppppppppmmmmmmmmmmmmmmnnnnnnnnnnnnvvvvvvvvvvvvvvvvvvvbhzehazefhlazejfhldkfalkjflkazefklahzeklfjazefhalzkefalzkefakzefazebf;zebfe;zj",3.25F,"Neuf" ,1);
		assertEquals(true,NormalisationDescription.setDescriptionNormalise(r1));
	}
}
