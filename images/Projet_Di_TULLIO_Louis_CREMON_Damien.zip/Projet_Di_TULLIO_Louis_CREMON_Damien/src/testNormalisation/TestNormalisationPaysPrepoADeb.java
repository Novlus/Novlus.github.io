package testNormalisation;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import modele.metier.Client;
import normalisation.NormalisationVille;

public class TestNormalisationPaysPrepoADeb 
{
	@Test
	public void TestVillePrepoADeb() 
	{
		Client cl1 = new Client( "CREMON", "Mathieu", "8 boulevard", "Fauborg", "54000", "A Metz", "Suisse");
		assertEquals("�-Metz",NormalisationVille.setVilleNormaliseadeb(cl1));
	}
}
