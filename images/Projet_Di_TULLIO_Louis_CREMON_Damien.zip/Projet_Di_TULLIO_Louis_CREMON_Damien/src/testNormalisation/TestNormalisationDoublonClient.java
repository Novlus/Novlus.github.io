package testNormalisation;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import factory.DAOFactory;
import factory.Persistance;
import modele.metier.Client;
import normalisation.NormalisationDoublonClient;

public class TestNormalisationDoublonClient 
{
	@Test
	public void NormalisationDoublonClient() throws Exception 
	{
		Client cl1 = new Client( "CREMON", "Mathieu", "8 boulevard", "Fauborg", "54000", "Nancy", "Belgique");
		Client cl2 =new Client( "CREMON", "Mathieu", "8 boulevard", "Fauborg", "54000", "Nancy", "Belgique");
		DAOFactory dao =DAOFactory.getDAOFactory(Persistance.LISTE_MEMOIRE);
		dao.getClientDAO().create(cl1);
		assertEquals(true,NormalisationDoublonClient.setDoublonNormalise(cl2,dao));
	}
}
