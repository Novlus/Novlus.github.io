package controller;

import java.io.File;
import java.io.IOException;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class Controller_Visualisation_Periodicite 
{
	@FXML
	private TextField text_id_periodicite, text_libelle_periodicite;
	
	@FXML
	private Button btn_retour_visualisation_periodicite;
	
	@FXML
	public void initialize()
	{

		this.text_id_periodicite.setText(String.valueOf(Controller_Table_Periodicite.id_periodicite));
		
		this.text_libelle_periodicite.setText(Controller_Table_Periodicite.libelle_periodicite);
	}
	
	public void choix_retour_visualisation_periodicite() throws Exception
	{
		Stage secondaryStage = new Stage();
		FXMLLoader loader = new FXMLLoader() ;
		java.net.URL url = new File("src/fxml/Table_Periodicite.fxml").toURI().toURL();
		Parent root = FXMLLoader.load(url);
		Scene scene = new Scene(root);
		secondaryStage.setScene(scene);
		secondaryStage.setTitle("Gestion des Periodicites");
		secondaryStage.setMaxWidth(700);
		secondaryStage.setMinWidth(700);
		secondaryStage.setMaxHeight(700);
		secondaryStage.setMinHeight(700);
		secondaryStage.show();
		Stage stage = (Stage) this.btn_retour_visualisation_periodicite.getScene().getWindow();
		stage.close();
	}
}
