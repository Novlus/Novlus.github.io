package controller;

import java.io.File;

import factory.DAOFactory;
import factory.Persistance;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import modele.metier.Periodicite;

public class Controller_Ajout_Periodicite extends Controller_Menu_Persistence
{
	@FXML private Button btn_valider,btn_retour;
	@FXML private TextField Text_Libelle;
	private DAOFactory dao = Controller_Menu_Persistence.dao;
	
	private Stage secondaryStage = new Stage();
	//private DAOFactory daos = DAOFactory.getDAOFactory(Persistance.LISTE_MEMOIRE);
	
	
	public void choix_valider() throws Exception
	{
		String text;
		text = Text_Libelle.getText();	
		Periodicite p1 = new Periodicite(text);
		this.dao.getPeriodiciteDAO().create(p1);
		FXMLLoader loader = new FXMLLoader() ;
		java.net.URL url = new File("src/fxml/Table_Periodicite.fxml").toURI().toURL();
		Parent root = FXMLLoader.load(url);
		Scene scene = new Scene(root);
		secondaryStage.setScene(scene);
		secondaryStage.setTitle("Gestion des Periodicites");
		secondaryStage.setMaxWidth(700);
		secondaryStage.setMinWidth(700);
		secondaryStage.setMaxHeight(700);
		secondaryStage.setMinHeight(700);
		secondaryStage.show();
		Stage stage = (Stage) btn_valider.getScene().getWindow();
		stage.close();
	
	
	}
	
	public void choix_retour() throws Exception
	{
		FXMLLoader loader = new FXMLLoader() ;
		java.net.URL url = new File("src/fxml/Table_Periodicite.fxml").toURI().toURL();
		Parent root = FXMLLoader.load(url);
		Scene scene = new Scene(root);
		secondaryStage.setScene(scene);
		secondaryStage.setTitle("Gestion des Periodicites");
		secondaryStage.setMaxWidth(700);
		secondaryStage.setMinWidth(700);
		secondaryStage.setMaxHeight(700);
		secondaryStage.setMinHeight(700);
		secondaryStage.show();
		Stage stage = (Stage) btn_retour.getScene().getWindow();
		stage.close();
	}
}
