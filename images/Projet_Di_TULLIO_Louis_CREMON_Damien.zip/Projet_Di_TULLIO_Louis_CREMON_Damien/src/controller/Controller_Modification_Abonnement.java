package controller;

import java.io.File;
import java.time.LocalDate;

import factory.DAOFactory;
import factory.Persistance;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import modele.metier.Abonnement;
import modele.metier.Client;
import modele.metier.Revue;
import normalisation.NormalisationDate;

public class Controller_Modification_Abonnement 
{
	@FXML
	private Button btn_modifier,btn_retour;
	@FXML
	private TextField text_jour_debut,text_mois_debut,text_annee_debut,text_jour_fin,text_mois_fin,text_annee_fin;
	@FXML
	private ComboBox<Client> cbx_client;
	@FXML
	private ComboBox<Revue>cbx_revue;
	@FXML
	private Label lbl_res;
	private int id_abonnement = Controller_Table_Abonnement.id_abonnement;
	
	private DAOFactory dao = Controller_Menu_Persistence.dao;
	
	public void initialize() throws Exception
	{

		this.text_jour_debut.setText(String.valueOf(Controller_Table_Abonnement.jour_deb));
		this.text_mois_debut.setText(String.valueOf(Controller_Table_Abonnement.mois_deb));
		this.text_annee_debut.setText(String.valueOf(Controller_Table_Abonnement.annee_deb));
		this.text_jour_fin.setText(String.valueOf(Controller_Table_Abonnement.jour_fin));
		this.text_mois_fin.setText(String.valueOf(Controller_Table_Abonnement.mois_fin));
		this.text_annee_fin.setText(String.valueOf(Controller_Table_Abonnement.annee_deb));
		this.cbx_client.setValue(dao.getClientDAO().getById(Controller_Table_Abonnement.id_client));
		this.cbx_client.setItems(FXCollections.observableArrayList(dao.getClientDAO().findAll()));
		this.cbx_revue.setValue(dao.getRevueDAO().getById(Controller_Table_Abonnement.id_revue));
		this.cbx_revue.setItems(FXCollections.observableArrayList(dao.getRevueDAO().findAll()));
	}
	
	public void choix_modifier() throws Exception
	
	{
		int jour_debut = Integer.parseInt(this.text_jour_debut.getText());
		int mois_debut = Integer.parseInt(this.text_mois_debut.getText());
		int annee_debut = Integer.parseInt(this.text_annee_debut.getText());
		int jour_fin = Integer.parseInt(this.text_jour_fin.getText());
		int mois_fin = Integer.parseInt(this.text_mois_fin.getText());
		int annee_fin = Integer.parseInt(this.text_annee_fin.getText());
		Client c1 =(Client)cbx_client.getValue();
		Revue r1 =(Revue)cbx_revue.getValue();
		int client = c1.getId_client() ;
		int revue = r1.getId_revue();
		LocalDate date_debut = LocalDate.of(annee_debut, mois_debut, jour_debut);
		LocalDate date_fin = LocalDate.of(annee_fin, mois_fin, jour_fin);
		Abonnement a1 = new Abonnement(this.id_abonnement,date_debut,date_fin,client,revue);
		if(NormalisationDate.setDateNormalise(a1)== true)
		{
			this.lbl_res.setText("Veuillez saisir une date de debut inferieur � celle de fin");
		}
		else if(NormalisationDate.setDateNormalise(a1)== false)
	{
		this.dao.getAbonnementDAO().update(a1);
		Stage secondaryStage = new Stage();
		FXMLLoader loader = new FXMLLoader() ;
		java.net.URL url = new File("src/fxml/Table_Abonnement.fxml").toURI().toURL();
		Parent root = FXMLLoader.load(url);
		Scene scene = new Scene(root);
		secondaryStage.setScene(scene);
		secondaryStage.setTitle("Gestion des Abonnements");
		secondaryStage.setMaxWidth(700);
		secondaryStage.setMinWidth(700);
		secondaryStage.setMaxHeight(700);
		secondaryStage.setMinHeight(700);
		secondaryStage.show();
		Stage stage = (Stage) this.btn_modifier.getScene().getWindow();
		stage.close();
		}
	}
	
	public void choix_retour() throws Exception
	{
		Stage secondaryStage = new Stage();
		FXMLLoader loader = new FXMLLoader() ;
		java.net.URL url = new File("src/fxml/Table_Abonnement.fxml").toURI().toURL();
		Parent root = FXMLLoader.load(url);
		Scene scene = new Scene(root);
		secondaryStage.setScene(scene);
		secondaryStage.setTitle("Gestion des Abonnements");
		secondaryStage.setMaxWidth(700);
		secondaryStage.setMinWidth(700);
		secondaryStage.setMaxHeight(700);
		secondaryStage.setMinHeight(700);
		secondaryStage.show();
		Stage stage = (Stage) this.btn_retour.getScene().getWindow();
		stage.close();
	}
}
