package controller;

import java.io.File;
import java.io.IOException;

import factory.DAOFactory;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import modele.metier.Periodicite;

public class Controller_Modification_Periodicite extends Controller_Menu_Persistence
{
	@FXML
	private Button btn_modifier_modification_periodicite,btn_retour;
	@FXML
	private TextField text_libelle ;
	private int id_periodicite = Controller_Table_Periodicite.id_periodicite;
	private DAOFactory dao = Controller_Menu_Persistence.dao;
	
	public void initialize()
	{

		this.text_libelle.setText(Controller_Table_Periodicite.libelle_periodicite);
	}
	
	public void choix_modification_periodicite() throws Exception
	{
		Periodicite p1 = new Periodicite(this.id_periodicite,this.text_libelle.getText());
		this.dao.getPeriodiciteDAO().update(p1);
		Stage secondaryStage = new Stage();
		FXMLLoader loader = new FXMLLoader() ;
		java.net.URL url = new File("src/fxml/Table_Periodicite.fxml").toURI().toURL();
		Parent root = FXMLLoader.load(url);
		Scene scene = new Scene(root);
		secondaryStage.setScene(scene);
		secondaryStage.setTitle("Gestion des Periodicites");
		secondaryStage.setMaxWidth(700);
		secondaryStage.setMinWidth(700);
		secondaryStage.setMaxHeight(700);
		secondaryStage.setMinHeight(700);
		secondaryStage.show();
		Stage stage = (Stage) this.btn_modifier_modification_periodicite.getScene().getWindow();
		stage.close();
	}
	
	public void choix_retour() throws Exception
	{
		Stage secondaryStage = new Stage();
		FXMLLoader loader = new FXMLLoader() ;
		java.net.URL url = new File("src/fxml/Table_Periodicite.fxml").toURI().toURL();
		Parent root = FXMLLoader.load(url);
		Scene scene = new Scene(root);
		secondaryStage.setScene(scene);
		secondaryStage.setTitle("Gestion des Periodicites");
		secondaryStage.setMaxWidth(700);
		secondaryStage.setMinWidth(700);
		secondaryStage.setMaxHeight(700);
		secondaryStage.setMinHeight(700);
		secondaryStage.show();
		Stage stage = (Stage) this.btn_retour.getScene().getWindow();
		stage.close();
	}

}
