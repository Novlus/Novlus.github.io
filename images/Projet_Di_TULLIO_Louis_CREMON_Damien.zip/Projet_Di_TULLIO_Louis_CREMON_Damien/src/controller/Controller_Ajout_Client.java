package controller;

import java.io.File;

import factory.DAOFactory;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import modele.metier.Client;
import modele.metier.Periodicite;
import normalisation.NormalisationCodePostal;
import normalisation.NormalisationNoRue;
import normalisation.NormalisationPays;
import normalisation.NormalisationVille;
import normalisation.NormalisationVoie;

public class Controller_Ajout_Client extends Controller_Menu_Persistence
{
	@FXML private Button btn_valider,btn_retour;
	@FXML private TextField text_nom,text_prenom,text_numero_rue,text_voie,text_code_postal,text_ville,text_pays;
	
	private Stage secondaryStage = new Stage();
	private DAOFactory dao = Controller_Menu_Persistence.dao;
	
	
	
	
	
	public void choix_valider() throws Exception
	{
		
		Client c1 = new Client(text_nom.getText(),text_prenom.getText(),text_numero_rue.getText(),text_voie.getText(),text_code_postal.getText(),text_ville.getText(),text_pays.getText());
		Controller_Table_Client.Normalise(c1);
		this.dao.getClientDAO().create(c1);
		FXMLLoader loader = new FXMLLoader() ;
		java.net.URL url = new File("src/fxml/Table_Client.fxml").toURI().toURL();
		Parent root = FXMLLoader.load(url);
		
		Scene scene = new Scene(root);
		secondaryStage.setScene(scene);
		secondaryStage.setTitle("Gestion des Clients");
		secondaryStage.setMaxWidth(700);
		secondaryStage.setMinWidth(700);
		secondaryStage.setMaxHeight(700);
		secondaryStage.setMinHeight(700);
		secondaryStage.show();
		Stage stage = (Stage) btn_valider.getScene().getWindow();
		stage.close();
	
	
	}
	
	public void choix_retour() throws Exception
	
	{
		FXMLLoader loader = new FXMLLoader() ;
		java.net.URL url = new File("src/fxml/Table_Client.fxml").toURI().toURL();
		Parent root = FXMLLoader.load(url);
		Scene scene = new Scene(root);
		secondaryStage.setScene(scene);
		secondaryStage.setTitle("Gestion des Clients");
		secondaryStage.setMaxWidth(700);
		secondaryStage.setMinWidth(700);
		secondaryStage.setMaxHeight(700);
		secondaryStage.setMinHeight(700);
		secondaryStage.show();
		Stage stage = (Stage) btn_retour.getScene().getWindow();
		stage.close();
		
	}
}
