package controller;

import java.io.File;
import java.io.IOException;

import factory.DAOFactory;
import factory.Persistance;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import modele.metier.Periodicite;
import modele.metier.Revue;
import normalisation.NormalisationDescription;

public class Controller_Table_Revue extends Controller_Menu_Persistence implements ChangeListener<Revue>  
{
	@FXML
	 private TableView<Revue> tblRevue ;
	 @FXML
	 private Button btn_supprimer_revue;
	 @FXML
	 private Button btn_visualiser_revue;
	 @FXML
	 private Button btn_modifier_revue;
	 @FXML
	 private Button btn_ajouter_revue;
	 @FXML
	 private Button btn_retour_revue;
	 
	 private Stage primaryStage =new Stage() ;
	 
	 private DAOFactory dao = Controller_Menu_Persistence.dao;
	 
	 
	 
	 public static int id_periodicite2;
	 public static String description2;
	 public static int id_revue2;
	 public static String titre2;
	 public static float tarif2;
	 public static String visuel2;
	 
	
	 
	 
	 public void initialize() throws Exception
		{
	    TableColumn <Revue, String> colTitre = new TableColumn<> ("Titre");
	 	colTitre.setCellValueFactory(new PropertyValueFactory<Revue, String>("titre"));
	 	TableColumn <Revue, String> colDescription = new TableColumn<> ("Description");
	 	colDescription.setCellValueFactory(new PropertyValueFactory<Revue, String>("description"));
	 	TableColumn <Revue, Float> colTarif = new TableColumn<> ("Tarif");
	 	colTarif.setCellValueFactory(new PropertyValueFactory<Revue, Float>("tarif_numero"));
	 	TableColumn <Revue, String> colVisuel = new TableColumn<> ("Visuel");
	 	colVisuel.setCellValueFactory(new PropertyValueFactory<Revue, String>("visuel"));
	 	TableColumn <Revue, Integer> colId_Periodicite = new TableColumn<> ("Id Periodicit�");
	 	colId_Periodicite.setCellValueFactory(new PropertyValueFactory<Revue, Integer>("id_periodicite"));
	 	this.tblRevue.getColumns().setAll(colTitre);
	 	this.tblRevue.getColumns().add(colDescription);
	 	this.tblRevue.getColumns().add(colTarif);
	 	this.tblRevue.getColumns().add(colVisuel);
	 	this.tblRevue.getColumns().add(colId_Periodicite);
	 	this.tblRevue.getItems().addAll(this.dao.getRevueDAO().findAll());
	 	this.tblRevue.getSelectionModel().selectedItemProperty().addListener(this);
	 	this.btn_supprimer_revue.setDisable(true);
	 	this.btn_visualiser_revue.setDisable(true);
	 	this.btn_modifier_revue.setDisable(true);
	 	this.btn_ajouter_revue.setDisable(false);
	   
		 	
		}
	 
	 public void changed(ObservableValue<? extends Revue> observable, Revue oldValue, Revue newValue)
	 {
		 this.btn_supprimer_revue.setDisable(newValue == null);
		 this.btn_modifier_revue.setDisable(newValue == null);
		 this.btn_visualiser_revue.setDisable(newValue == null);
		 this.btn_ajouter_revue.setDisable(oldValue == null);
	 }
	 
	 public void choix_supprimer_revue() 
	 {
		 int selectedIndex = this.tblRevue.getSelectionModel().getSelectedIndex();
		 Revue r1 =this.tblRevue.getSelectionModel().getSelectedItem();
		 this.dao.getRevueDAO().delete(r1);
		 this.tblRevue.getItems().remove(selectedIndex);
		 this.tblRevue.getSelectionModel().clearSelection();
	 }
	 
	 public void choix_ajouter_revue()
	 {
		 Parent root;
		try {
			java.net.URL url = new File("src/fxml/Ajout_Revue.fxml").toURI().toURL();
			root = FXMLLoader.load(url);
			FXMLLoader loader = new FXMLLoader() ;
			Scene scene = new Scene(root);
			primaryStage.setScene(scene);
			primaryStage.setTitle("Ajout d'une nouvelle Periodicite");
			primaryStage.setMaxWidth(700);
			primaryStage.setMinWidth(700);
			primaryStage.setMaxHeight(700);
			primaryStage.setMinHeight(700);
			primaryStage.show();
			Stage stage = (Stage)this.btn_ajouter_revue.getScene().getWindow();
			stage.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }
	 
	 public void choix_modifier_revue() throws Exception
	 {	this.id_revue2 = this.tblRevue.getSelectionModel().getSelectedItem().getId_revue();
	 	this.titre2 = this.tblRevue.getSelectionModel().getSelectedItem().getTitre(); 
	 	this.description2 = this.tblRevue.getSelectionModel().getSelectedItem().getDescription(); 
	 	this.tarif2 = this.tblRevue.getSelectionModel().getSelectedItem().getTarif_numero(); 
	 	this.visuel2 = this.tblRevue.getSelectionModel().getSelectedItem().getVisuel();
	 	this.id_periodicite2 = this.tblRevue.getSelectionModel().getSelectedItem().getId_periodicite();

	 	
		 Parent root;
		 java.net.URL url = new File("src/fxml/Modification_Revue.fxml").toURI().toURL();
		 root = FXMLLoader.load(url);
		 Scene scene = new Scene(root);
		 primaryStage.setScene(scene);
		 primaryStage.setTitle("modification d'une Periodicite");
		 primaryStage.setMaxWidth(700);
		 primaryStage.setMinWidth(700);
		 primaryStage.setMaxHeight(700);
		 primaryStage.setMinHeight(700);
		 primaryStage.show();
		 Stage stage = (Stage)this.btn_modifier_revue.getScene().getWindow();
		 stage.close();		
		}
	 
	 
	 public static void visualiser_id(int id)
	 {
		 System.out.println(id);
	 }
	 
	 
	 
	 public void choix_visualiser_revue() throws Exception
	 {
		 
		 this.id_periodicite2 = this.tblRevue.getSelectionModel().getSelectedItem().getId_periodicite();
		 this.titre2 = this.tblRevue.getSelectionModel().getSelectedItem().getTitre();
		 this.description2 = this.tblRevue.getSelectionModel().getSelectedItem().getDescription();
		 this.tarif2 = this.tblRevue.getSelectionModel().getSelectedItem().getTarif_numero();
		 this.id_revue2 = this.tblRevue.getSelectionModel().getSelectedItem().getId_revue();
		 this.visuel2 = this.tblRevue.getSelectionModel().getSelectedItem().getVisuel();
		 Parent root;
		 java.net.URL url = new File("src/fxml/Visualisation_Revue.fxml").toURI().toURL();
		 root = FXMLLoader.load(url);
		
		 Scene scene = new Scene((root));
		 
		 primaryStage.setScene(scene);
		 primaryStage.setTitle("visualisation d'une Periodicite");
		 primaryStage.setMaxWidth(700);
		 primaryStage.setMinWidth(700);
		 primaryStage.setMaxHeight(700);
		 primaryStage.setMinHeight(700);
		 primaryStage.show();
		 Stage stage = (Stage)this.btn_visualiser_revue.getScene().getWindow();
		 stage.close();	
		
	 }
	 
	 public void choix_retour_revue() throws Exception
	 {
		 	java.net.URL url = new File("src/fxml/Metier.fxml").toURI().toURL();
			Parent root = FXMLLoader.load(url);
			Stage stage = (Stage)this.btn_retour_revue.getScene().getWindow();
			stage.setScene(new Scene(root, 700,700));
			stage.setTitle("Gestion des metiers");
			stage.setMaxWidth(700);
			stage.setMinWidth(700);
			stage.setMaxHeight(700);
			stage.setMinHeight(700);
	 }
	 
	 
}
