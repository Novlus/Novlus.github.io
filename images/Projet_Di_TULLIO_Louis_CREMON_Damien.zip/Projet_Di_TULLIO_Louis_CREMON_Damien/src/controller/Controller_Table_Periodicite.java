package controller;

import java.io.File;
import java.io.IOException;

import factory.DAOFactory;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import modele.metier.Periodicite;

public class Controller_Table_Periodicite extends Controller_Menu_Persistence implements ChangeListener<Periodicite> 
{
	
 @FXML
 private TableView<Periodicite> tblPeriodicite ;
 @FXML
 private Button btn_supprimer_periodicite;
 @FXML
 private Button btn_visualiser_periodicite;
 @FXML
 private Button btn_modifier_periodicite;
 @FXML
 private Button btn_ajouter_periodicite;
 @FXML
 private Button btn_retour_periodicite;
 
 private Stage primaryStage =new Stage() ;
 
 private DAOFactory dao = Controller_Menu_Persistence.dao;
 public static int id_periodicite;
 public static String libelle_periodicite;
 
 
@FXML 
private AnchorPane id_anchor;

protected String libelle;
protected int id ;



 
 
 
 

public void initialize() throws Exception
	{
    TableColumn <Periodicite, String> colLibelle = new TableColumn<> ("Libelle");
 	colLibelle.setCellValueFactory(new PropertyValueFactory<Periodicite, String>("libelle"));
 	this.tblPeriodicite.getColumns().setAll(colLibelle);
 	this.tblPeriodicite.getItems().addAll(this.dao.getPeriodiciteDAO().findAll());
 	this.tblPeriodicite.getSelectionModel().selectedItemProperty().addListener(this);
 	this.btn_supprimer_periodicite.setDisable(true);
 	this.btn_visualiser_periodicite.setDisable(true);
 	this.btn_modifier_periodicite.setDisable(true);
 	this.btn_ajouter_periodicite.setDisable(false);
   
	 	
	}
 
 public void changed(ObservableValue<? extends Periodicite> observable, Periodicite oldValue, Periodicite newValue)
 {
	 this.btn_supprimer_periodicite.setDisable(newValue == null);
	 this.btn_modifier_periodicite.setDisable(newValue == null);
	 this.btn_visualiser_periodicite.setDisable(newValue == null);
	 this.btn_ajouter_periodicite.setDisable(oldValue == null);
 }
 
 public void choix_supprimer_periodicite() 
 {
	 int selectedIndex = this.tblPeriodicite.getSelectionModel().getSelectedIndex();
	 Periodicite p1 =this.tblPeriodicite.getSelectionModel().getSelectedItem();
	 this.dao.getPeriodiciteDAO().delete(p1); 
	 this.tblPeriodicite.getItems().remove(selectedIndex);
	 this.tblPeriodicite.getSelectionModel().clearSelection();
 }
 
 public void choix_ajout_periodicite()
 {
	 Parent root;
	try {
		java.net.URL url = new File("src/fxml/Ajout_Periodicite.fxml").toURI().toURL();
		root = FXMLLoader.load(url);
		FXMLLoader loader = new FXMLLoader() ;
		Scene scene = new Scene(root);
		primaryStage.setScene(scene);
		primaryStage.setTitle("Ajout d'une nouvelle Periodicite");
		primaryStage.setMaxWidth(700);
		primaryStage.setMinWidth(700);
		primaryStage.setMaxHeight(700);
		primaryStage.setMinHeight(700);
		primaryStage.show();
		Stage stage = (Stage)this.btn_ajouter_periodicite.getScene().getWindow();
		stage.close();
		
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
 }
 
 public void choix_modifier_periodicite() throws Exception
 {	
	this.id_periodicite = this.tblPeriodicite.getSelectionModel().getSelectedItem().getId_periodicite();
 	this.libelle_periodicite = this.tblPeriodicite.getSelectionModel().getSelectedItem().getLibelle();
	 Parent root;
	 java.net.URL url = new File("src/fxml/Modification_Periodicite.fxml").toURI().toURL();
	 root = FXMLLoader.load(url);
	
	 FXMLLoader loader = new FXMLLoader() ;
	 Scene scene = new Scene(root);
	 primaryStage.setScene(scene);
	 primaryStage.setTitle("modification d'une Periodicite");
	 primaryStage.setMaxWidth(700);
	 primaryStage.setMinWidth(700);
	 primaryStage.setMaxHeight(700);
	 primaryStage.setMinHeight(700);
	 primaryStage.show();
	 Stage stage = (Stage)this.btn_modifier_periodicite.getScene().getWindow();
	 stage.close();	
	}
 
 
 public static void visualiser_id(int id)
 {
	 System.out.println(id);
 }
 
 public void choix_visualiser_periodicite() throws Exception
 {
	 this.id_periodicite = this.tblPeriodicite.getSelectionModel().getSelectedItem().getId_periodicite();
	 this.libelle_periodicite = this.tblPeriodicite.getSelectionModel().getSelectedItem().getLibelle();
	 System.out.println("l'id  =p�riodicite est "+this.id+"le libelle est "+this.libelle);
	 
	 Parent root;
	 java.net.URL url = new File("src/fxml/Visualisation_Periodicite.fxml").toURI().toURL();
	 root = FXMLLoader.load(url);
	 Scene scene = new Scene((root));
	 
	 primaryStage.setScene(scene);
	 primaryStage.setTitle("visualisation d'une Periodicite");
	 primaryStage.setMaxWidth(700);
	 primaryStage.setMinWidth(700);
	 primaryStage.setMaxHeight(700);
	 primaryStage.setMinHeight(700);
	 primaryStage.show();
	 Stage stage = (Stage)this.btn_visualiser_periodicite.getScene().getWindow();
	 stage.close();
	
	 
 }
 
 public void choix_retour_periodicite() throws Exception
 {
	 	java.net.URL url = new File("src/fxml/Metier.fxml").toURI().toURL();
		Parent root = FXMLLoader.load(url);
		Stage stage = (Stage)this.btn_retour_periodicite.getScene().getWindow();
		stage.setScene(new Scene(root, 700,700));
		stage.setTitle("Gestion des metiers");
		stage.setMaxWidth(700);
		stage.setMinWidth(700);
		stage.setMaxHeight(700);
		stage.setMinHeight(700);
 }
}


