package controller;

import java.io.File;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class Controller_Visualisation_Revue 
{
	@FXML
	private TextField text_id_periodicite,text_id_revue,text_titre,text_description,text_tarif,text_visuel;
	
	@FXML
	private Button btn_retour;
	
	public void initialize()
	{
		this.text_id_revue.setText(String.valueOf(Controller_Table_Revue.id_revue2));
		this.text_id_periodicite.setText(String.valueOf(Controller_Table_Revue.id_periodicite2));
		this.text_titre.setText(String.valueOf(Controller_Table_Revue.titre2));
		this.text_tarif.setText(String.valueOf(Controller_Table_Revue.tarif2));
		this.text_description.setText(String.valueOf(Controller_Table_Revue.description2));
		this.text_visuel.setText(String.valueOf(Controller_Table_Revue.visuel2));
	}
	
	
	public void choix_retour()throws Exception 
	{
		Stage secondaryStage = new Stage();
		FXMLLoader loader = new FXMLLoader() ;
		java.net.URL url = new File("src/fxml/Table_Revue.fxml").toURI().toURL();
		Parent root = FXMLLoader.load(url);
		Scene scene = new Scene(root);
		secondaryStage.setScene(scene);
		secondaryStage.setTitle("Gestion des Revues");
		secondaryStage.setMaxWidth(700);
		secondaryStage.setMinWidth(700);
		secondaryStage.setMaxHeight(700);
		secondaryStage.setMinHeight(700);
		secondaryStage.show();
		Stage stage = (Stage) this.btn_retour.getScene().getWindow();
		stage.close();
	}
}
