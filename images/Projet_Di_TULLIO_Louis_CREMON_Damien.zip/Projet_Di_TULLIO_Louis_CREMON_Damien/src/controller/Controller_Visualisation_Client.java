package controller;

import java.io.File;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class Controller_Visualisation_Client 
{
	@FXML
	private TextField text_id,text_nom, text_prenom,text_numero_rue,text_voie,text_code_postal,text_ville,text_pays;
	
	@FXML
	private Button btn_retour;
	
	@FXML
	public void initialize()
	{
		this.text_id.setText(String.valueOf(Controller_Table_Client.id_client));

		this.text_nom.setText(String.valueOf(Controller_Table_Client.nom));
		
		this.text_prenom.setText(Controller_Table_Client.prenom);
		this.text_numero_rue.setText(Controller_Table_Client.no_rue);
		this.text_voie.setText(Controller_Table_Client.voie);
		this.text_code_postal.setText(Controller_Table_Client.code_postal);
		this.text_ville.setText(Controller_Table_Client.ville);
		this.text_pays.setText(Controller_Table_Client.pays);
	}
	
	public void choix_retour() throws Exception
	{
		Stage secondaryStage = new Stage();
		java.net.URL url = new File("src/fxml/Ajout_Client.fxml").toURI().toURL();
		Parent root = FXMLLoader.load(url);
		Scene scene = new Scene(root);
		secondaryStage.setScene(scene);
		secondaryStage.setTitle("Gestion des Client");
		secondaryStage.setMaxWidth(700);
		secondaryStage.setMinWidth(700);
		secondaryStage.setMaxHeight(700);
		secondaryStage.setMinHeight(700);
		secondaryStage.show();
		Stage stage = (Stage) this.btn_retour.getScene().getWindow();
		stage.close();
	}
}
