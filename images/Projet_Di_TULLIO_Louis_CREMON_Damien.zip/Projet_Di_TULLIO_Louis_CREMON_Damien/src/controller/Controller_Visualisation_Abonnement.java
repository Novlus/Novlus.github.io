package controller;

import java.io.File;

import factory.DAOFactory;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class Controller_Visualisation_Abonnement 
{
	@FXML
	private TextField text_id,text_id_client,text_id_revue,text_jour_debut,text_jour_fin,text_mois_debut,text_mois_fin,text_annee_debut,text_annee_fin;
	
	@FXML
	private Button btn_retour;
	

	
	@FXML
	public void initialize()
	{
		this.text_id.setText(String.valueOf(Controller_Table_Abonnement.id_abonnement));
		this.text_id_client.setText(String.valueOf(Controller_Table_Abonnement.id_client));
		this.text_id_revue.setText(String.valueOf(Controller_Table_Abonnement.id_revue));

		this.text_jour_debut.setText(String.valueOf(Controller_Table_Abonnement.jour_deb));
		this.text_jour_fin.setText(String.valueOf(Controller_Table_Abonnement.jour_fin));
		this.text_mois_debut.setText(String.valueOf(Controller_Table_Abonnement.mois_deb));
		this.text_mois_fin.setText(String.valueOf(Controller_Table_Abonnement.mois_fin));
		this.text_annee_debut.setText(String.valueOf(Controller_Table_Abonnement.annee_deb));
		this.text_annee_fin.setText(String.valueOf(Controller_Table_Abonnement.annee_fin));
		
	}
	
	public void choix_retour() throws Exception
	{
		Stage secondaryStage = new Stage();
		java.net.URL url = new File("src/fxml/Table_Abonnement.fxml").toURI().toURL();
		Parent root = FXMLLoader.load(url);
		Scene scene = new Scene(root);
		secondaryStage.setScene(scene);
		secondaryStage.setTitle("Gestion des Abonnements");
		secondaryStage.setMaxWidth(700);
		secondaryStage.setMinWidth(700);
		secondaryStage.setMaxHeight(700);
		secondaryStage.setMinHeight(700);
		secondaryStage.show();
		Stage stage = (Stage) this.btn_retour.getScene().getWindow();
		stage.close();
	}
}
