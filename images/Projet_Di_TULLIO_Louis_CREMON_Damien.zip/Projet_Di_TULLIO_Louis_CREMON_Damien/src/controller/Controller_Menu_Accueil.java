package controller;

import java.io.File;

import javax.print.DocFlavor.URL;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class Controller_Menu_Accueil 
{
	@FXML
	Button btn_Persistence, btn_fermer;
	
	public void choix_Persitence() throws Exception
	{
		java.net.URL url = new File("src/fxml/Persistance.fxml").toURI().toURL();
		Parent root = FXMLLoader.load(url);
		Stage stage = (Stage)this.btn_Persistence.getScene().getWindow();
		stage.setScene(new Scene(root, 700,500));
		stage.setTitle("Gestion des Persistences");
		stage.setMaxWidth(700);
		stage.setMinWidth(700);
		stage.setMaxHeight(550);
		stage.setMinHeight(550);
	}
	
	
	
	public void choix_Fermer() throws Exception
	{
		
		Stage stage = (Stage) btn_fermer.getScene().getWindow();
		stage.close();
	}
}
