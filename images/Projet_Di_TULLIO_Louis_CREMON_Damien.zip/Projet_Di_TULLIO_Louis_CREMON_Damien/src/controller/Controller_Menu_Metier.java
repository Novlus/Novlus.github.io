package controller;

import java.io.File;
import java.io.IOException;

import application.Main;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class Controller_Menu_Metier extends Main
{
	@FXML private Button btn_Periodicite;
	@FXML private Button btn_Revue;
	@FXML private Button btn_Abonnement;
	@FXML private Button btn_Client;
	@FXML private Button btn_retour_metier;
	@FXML private AnchorPane id_anchor;	
	
	
	public void choix_Periodicite () throws Exception
	{
		java.net.URL url = new File("src/fxml/Table_Periodicite.fxml").toURI().toURL();
		Parent root = FXMLLoader.load(url);
		Stage stage = (Stage)this.btn_Periodicite.getScene().getWindow();
		stage.setScene(new Scene(root, 700,500));
		stage.setTitle("Gestion des Periodicites");
		stage.setMaxWidth(700);
		stage.setMinWidth(700);
		stage.setMaxHeight(700);
		stage.setMinHeight(700);
	}
	
	public void choix_retour_metier () throws Exception
	{
		java.net.URL url = new File("src/fxml/Persistance.fxml").toURI().toURL();
		Parent root = FXMLLoader.load(url);
		Stage stage = (Stage)this.btn_retour_metier.getScene().getWindow();
		stage.setScene(new Scene(root, 700,500));
		stage.setTitle("Gestion des Persistences");
		stage.setMaxWidth(700);
		stage.setMinWidth(700);
		stage.setMaxHeight(700);
		stage.setMinHeight(700);
	}
	
	public void choix_Revue () throws Exception
	{
		java.net.URL url = new File("src/fxml/Table_Revue.fxml").toURI().toURL();
		Parent root = FXMLLoader.load(url);
		Stage stage = (Stage)this.btn_Revue.getScene().getWindow();
		stage.setScene(new Scene(root, 700,700));
		stage.setTitle("Gestion des Revues");
		stage.setMaxWidth(700);
		stage.setMinWidth(700);
		stage.setMaxHeight(700);
		stage.setMinHeight(700);
	}
	
	public void choix_Client () throws Exception
	{
		java.net.URL url = new File("src/fxml/Table_Client.fxml").toURI().toURL();
		Parent root = FXMLLoader.load(url);
		Stage stage = (Stage)this.btn_Client.getScene().getWindow();
		stage.setScene(new Scene(root, 700,700));
		stage.setTitle("Gestion des Clients");
		stage.setMaxWidth(700);
		stage.setMinWidth(700);
		stage.setMaxHeight(700);
		stage.setMinHeight(700);
		
	}
	
	public void choix_Abonnement () throws Exception
	{
		java.net.URL url = new File("src/fxml/Table_Abonnement.fxml").toURI().toURL();
		Parent root = FXMLLoader.load(url);
		Stage stage = (Stage)this.btn_Abonnement.getScene().getWindow();
		stage.setScene(new Scene(root, 700,700));
		stage.setTitle("Gestion des Clients");
		stage.setMaxWidth(700);
		stage.setMinWidth(700);
		stage.setMaxHeight(700);
		stage.setMinHeight(700);
	}
	
	
}
