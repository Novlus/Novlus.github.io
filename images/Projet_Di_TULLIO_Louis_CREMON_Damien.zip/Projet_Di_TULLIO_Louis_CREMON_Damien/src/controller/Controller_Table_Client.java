package controller;

import java.io.File;
import java.io.IOException;

import factory.DAOFactory;
import factory.Persistance;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import modele.metier.Client;
import modele.metier.Revue;
import normalisation.NormalisationCodePostal;
import normalisation.NormalisationNoRue;
import normalisation.NormalisationPays;
import normalisation.NormalisationVille;
import normalisation.NormalisationVoie;

public class Controller_Table_Client extends Controller_Menu_Persistence implements ChangeListener<Client>
{

	 @FXML
	 private TableView<Client> tblClient ;
	 @FXML
	 private Button btn_supprimer_client;
	 @FXML
	 private Button btn_visualiser_client;
	 @FXML
	 private Button btn_modifier_client;
	 @FXML
	 private Button btn_ajouter_client;
	 @FXML
	 private Button btn_retour_client;
	 
	 private Stage primaryStage =new Stage() ;
	 
	 private DAOFactory dao = Controller_Menu_Persistence.dao;
	 
	 public static String nom,prenom,no_rue,voie,code_postal,ville,pays;
	 public static int id_client;
	 
	 
	 
	 	public void initialize() throws Exception
	 	{
	 		TableColumn <Client, String> colNom = new TableColumn<> ("Nom");
	 		colNom.setCellValueFactory(new PropertyValueFactory<Client, String>("nom"));
	 		TableColumn <Client, String> colPrenom = new TableColumn<> ("Prenom");
	 		colPrenom.setCellValueFactory(new PropertyValueFactory<Client, String>("prenom"));
	 		TableColumn <Client, String> colNoRue = new TableColumn<> ("Numero rue");
	 		colNoRue.setCellValueFactory(new PropertyValueFactory<Client, String>("no_rue"));
	 		TableColumn <Client, String> colVoie = new TableColumn<> ("Voie");
	 		colVoie.setCellValueFactory(new PropertyValueFactory<Client, String>("voie"));
	 		TableColumn <Client, String> colCodePostal = new TableColumn<> ("Code postal");
	 		colCodePostal.setCellValueFactory(new PropertyValueFactory<Client, String>("code_postal"));
	 		TableColumn <Client, String> colVille = new TableColumn<> ("Ville");
	 		colVille.setCellValueFactory(new PropertyValueFactory<Client, String>("ville"));
	 		TableColumn <Client, String> colPays = new TableColumn<> ("Pays");
	 		colPays.setCellValueFactory(new PropertyValueFactory<Client, String>("pays"));
	 		this.tblClient.getColumns().setAll(colNom);
	 		this.tblClient.getColumns().add(colPrenom);
	 		this.tblClient.getColumns().add(colNoRue);
	 		this.tblClient.getColumns().add(colVoie);
	 		this.tblClient.getColumns().add(colCodePostal);
	 		this.tblClient.getColumns().add(colVille);
	 		this.tblClient.getColumns().add(colPays);
	 		this.tblClient.getItems().addAll(this.dao.getClientDAO().findAll());
	 		this.tblClient.getSelectionModel().selectedItemProperty().addListener(this);
	 		this.btn_supprimer_client.setDisable(true);
	 		this.btn_visualiser_client.setDisable(true);
	 		this.btn_modifier_client.setDisable(true);
	 		this.btn_ajouter_client.setDisable(false);
	 	}
	 	
	 	public void changed(ObservableValue<? extends Client> observable, Client oldValue, Client newValue)
		 {
			 this.btn_supprimer_client.setDisable(newValue == null);
			 this.btn_modifier_client.setDisable(newValue == null);
			 this.btn_visualiser_client.setDisable(newValue == null);
			 this.btn_ajouter_client.setDisable(oldValue == null);
		 }
	 	
	 	public void choix_supprimer_client() 
		 {
			 int selectedIndex = this.tblClient.getSelectionModel().getSelectedIndex();
			 Client c1 =this.tblClient.getSelectionModel().getSelectedItem();
			 this.dao.getClientDAO().delete(c1);
			 this.tblClient.getItems().remove(selectedIndex);
			 this.tblClient.getSelectionModel().clearSelection();
		 }
	 	
	 	public static Client Normalise (Client c1)
	 	{
	 		NormalisationCodePostal.SetCodePostalNormalisePays(c1);
			NormalisationCodePostal.setCodePostalNormalise(c1);
			NormalisationNoRue.SetNoRueVirguleFin(c1);
			NormalisationPays.setPaysNormaliseBelg(c1);
			NormalisationPays.setPaysNormaliseLux(c1);
			NormalisationPays.setPaysNormaliseSuisse(c1);
			NormalisationVille.setVilleNormalise(c1);
			NormalisationVille.setVilleNormalisea(c1);
			NormalisationVille.setVilleNormaliseadeb(c1);
			NormalisationVille.setVilleNormaliseaux(c1);
			NormalisationVille.setVilleNormaliseauxdeb(c1);
			NormalisationVille.setVilleNormalisele(c1);
			NormalisationVille.setVilleNormaliseLedeb(c1);
			NormalisationVille.setVilleNormaliseles(c1);
			NormalisationVille.setVilleNormaliseLesdeb(c1);
			NormalisationVille.setVilleNormalisesous(c1);
			NormalisationVille.setVilleNormaliseSousdeb(c1);
			NormalisationVille.setVilleNormaliseSt(c1);
			NormalisationVille.setVilleNormaliseStdeb(c1);
			NormalisationVille.setVilleNormaliseSte(c1);
			NormalisationVille.setVilleNormaliseStedeb(c1);
			NormalisationVille.setVilleNormalisesur(c1);
			NormalisationVille.setVilleNormaliseSurdeb(c1);
			NormalisationVoie.setVoieNormaliseavenue(c1);
			NormalisationVoie.setVoieNormaliseboulevard(c1);
			NormalisationVoie.setVoieNormalisefaubourg(c1);
			NormalisationVoie.setVoieNormaliseplace(c1);
			
			return c1;
	 	}
	 	public void choix_ajouter_client()
		 {
			 Parent root;
			try {
				java.net.URL url = new File("src/fxml/Ajout_Client.fxml").toURI().toURL();
				root = FXMLLoader.load(url);
				FXMLLoader loader = new FXMLLoader() ;
				Scene scene = new Scene(root);
				primaryStage.setScene(scene);
				primaryStage.setTitle("Ajout d'un nouveau Client");
				primaryStage.setMaxWidth(700);
				primaryStage.setMinWidth(700);
				primaryStage.setMaxHeight(700);
				primaryStage.setMinHeight(700);
				primaryStage.show();
				Stage stage = (Stage)this.btn_ajouter_client.getScene().getWindow();
				stage.close();
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 }
		 
		 public void choix_modifier_client() throws Exception
		 {	this.id_client = this.tblClient.getSelectionModel().getSelectedItem().getId_client();
		 	this.nom = this.tblClient.getSelectionModel().getSelectedItem().getNom(); 
		 	this.prenom = this.tblClient.getSelectionModel().getSelectedItem().getPrenom(); 
		 	this.no_rue = this.tblClient.getSelectionModel().getSelectedItem().getNo_rue(); 
		 	this.voie = this.tblClient.getSelectionModel().getSelectedItem().getVoie();
		 	this.ville = this.tblClient.getSelectionModel().getSelectedItem().getVille();
		 	this.pays = this.tblClient.getSelectionModel().getSelectedItem().getPays();
		 	this.code_postal = this.tblClient.getSelectionModel().getSelectedItem().getCode_postal();
			Parent root;
			java.net.URL url = new File("src/fxml/Modification_Client.fxml").toURI().toURL();
			root = FXMLLoader.load(url);
			FXMLLoader loader = new FXMLLoader() ;
			 Scene scene = new Scene(root);
			 primaryStage.setScene(scene);
			 primaryStage.setTitle("modification d'un Client");
			 primaryStage.setMaxWidth(700);
			 primaryStage.setMinWidth(700);
			 primaryStage.setMaxHeight(700);
			 primaryStage.setMinHeight(700);
			 primaryStage.show();
			 //primaryStage = (primaryStage)this.
			 //primaryStage.get
			 //Stage stage = (Stage)this.btn_ajouter.getScene().getWindow();
			 //stage.close();
			 Stage stage = (Stage)this.btn_modifier_client.getScene().getWindow();
			 stage.close();		
			}
		 
		 
		
		 
		 public void choix_visualiser_client() throws Exception
		 {
			 
			 this.id_client = this.tblClient.getSelectionModel().getSelectedItem().getId_client();
			 this.nom = this.tblClient.getSelectionModel().getSelectedItem().getNom(); 
			 this.prenom = this.tblClient.getSelectionModel().getSelectedItem().getPrenom(); 
			 this.no_rue = this.tblClient.getSelectionModel().getSelectedItem().getNo_rue(); 
			 this.voie = this.tblClient.getSelectionModel().getSelectedItem().getVoie();
			 this.ville = this.tblClient.getSelectionModel().getSelectedItem().getVille();
			 this.pays = this.tblClient.getSelectionModel().getSelectedItem().getPays();
			 this.code_postal = this.tblClient.getSelectionModel().getSelectedItem().getCode_postal();
			 Parent root;
			 java.net.URL url = new File("src/fxml/Visualisation_Client.fxml").toURI().toURL();
			 root = FXMLLoader.load(url);
			 Scene scene = new Scene((root));
			 
			 primaryStage.setScene(scene);
			 primaryStage.setTitle("visualisation d'un Client");
			 primaryStage.setMaxWidth(700);
			 primaryStage.setMinWidth(700);
			 primaryStage.setMaxHeight(700);
			 primaryStage.setMinHeight(700);
			 primaryStage.show();
			 Stage stage = (Stage)this.btn_visualiser_client.getScene().getWindow();
			 stage.close();	
			
		 }
	 	
	 	
	 	 public void choix_retour_client() throws Exception
		 {
	 		 	java.net.URL url = new File("src/fxml/Metier.fxml").toURI().toURL();
	 		 	Parent root = FXMLLoader.load(url);
				Stage stage = (Stage)this.btn_retour_client.getScene().getWindow();
				stage.setScene(new Scene(root, 700,700));
				stage.setTitle("Gestion des metiers");
				stage.setMaxWidth(700);
				stage.setMinWidth(700);
				stage.setMaxHeight(700);
				stage.setMinHeight(700);
		 }

}
