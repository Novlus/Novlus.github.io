package controller;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;

import factory.DAOFactory;
import factory.Persistance;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import modele.metier.Abonnement;
import modele.metier.Revue;


public class Controller_Table_Abonnement extends Controller_Menu_Persistence implements ChangeListener<Abonnement>
{
	 @FXML
	 private TableView<Abonnement> tblAbonnement ;
	 @FXML
	 private Button btn_supprimer_abonnement;
	 @FXML
	 private Button btn_visualiser_abonnement;
	 @FXML
	 private Button btn_modifier_abonnement;
	 @FXML
	 private Button btn_ajouter_abonnement;
	 @FXML
	 private Button btn_retour_abonnement;
	 
	 private Stage primaryStage =new Stage() ;
	 
	 private DAOFactory dao = Controller_Menu_Persistence.dao;
	 
	 public static int id_abonnement,id_client,id_revue;
	 public static LocalDate date_debut,date_fin;
	 public static int jour_deb,mois_deb,annee_deb,jour_fin,mois_fin,annee_fin;
	 
	 public void initialize() throws Exception
		{
	    TableColumn <Abonnement, LocalDate> colDateDebut = new TableColumn<> ("Date_de_debut");
	 	colDateDebut.setCellValueFactory(new PropertyValueFactory<Abonnement, LocalDate>("date_debut"));
	 	TableColumn <Abonnement, LocalDate> colDateFin = new TableColumn<> ("Date_de_fin");
	 	colDateFin.setCellValueFactory(new PropertyValueFactory<Abonnement, LocalDate>("date_fin"));
	 	TableColumn <Abonnement, Integer> colIdClient = new TableColumn<> ("Id_Client");
	 	colIdClient.setCellValueFactory(new PropertyValueFactory<Abonnement, Integer>("id_client"));
	 	TableColumn <Abonnement,Integer> colIdRevue = new TableColumn<> ("Id_Revue");
	 	colIdRevue.setCellValueFactory(new PropertyValueFactory<Abonnement, Integer>("id_revue"));
	 	this.tblAbonnement.getColumns().setAll(colDateDebut);
	 	this.tblAbonnement.getColumns().add(colDateFin);
	 	this.tblAbonnement.getColumns().add(colIdClient);
	 	this.tblAbonnement.getColumns().add(colIdRevue);
	 	this.tblAbonnement.getItems().addAll(this.dao.getAbonnementDAO().findAll());
	 	this.tblAbonnement.getSelectionModel().selectedItemProperty().addListener(this);
	 	this.btn_supprimer_abonnement.setDisable(true);
	 	this.btn_visualiser_abonnement.setDisable(true);
	 	this.btn_modifier_abonnement.setDisable(true);
	 	this.btn_ajouter_abonnement.setDisable(false);	
		}
	 
	 public void changed(ObservableValue<? extends Abonnement> observable, Abonnement oldValue, Abonnement newValue)
	 {
		 this.btn_supprimer_abonnement.setDisable(newValue == null);
		 this.btn_modifier_abonnement.setDisable(newValue == null);
		 this.btn_visualiser_abonnement.setDisable(newValue == null);
		 this.btn_ajouter_abonnement.setDisable(oldValue == null);
	 }
	 
	 public void choix_supprimer_abonnement() 
	 {
		 int selectedIndex = this.tblAbonnement.getSelectionModel().getSelectedIndex();
		 Abonnement a1 =this.tblAbonnement.getSelectionModel().getSelectedItem();
		 this.dao.getAbonnementDAO().delete(a1);
		 this.tblAbonnement.getItems().remove(selectedIndex);
		 this.tblAbonnement.getSelectionModel().clearSelection();
	 }
	 
	 public void choix_ajouter_abonnement() 
	 {
		 Parent root;
			try {
				java.net.URL url = new File("src/fxml/Ajout_Abonnement.fxml").toURI().toURL();
				root = FXMLLoader.load(url);
				FXMLLoader loader = new FXMLLoader() ;
				Scene scene = new Scene(root);
				primaryStage.setScene(scene);
				primaryStage.setTitle("Ajout d'un nouvelle Abonnement");
				primaryStage.setMaxWidth(700);
				primaryStage.setMinWidth(700);
				primaryStage.setMaxHeight(700);
				primaryStage.setMinHeight(700);
				primaryStage.show();
				Stage stage = (Stage)this.btn_ajouter_abonnement.getScene().getWindow();
				stage.close();
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 
	 }
	 public void choix_modifier_abonnement() throws Exception
	 {
		 this.id_client = this.tblAbonnement.getSelectionModel().getSelectedItem().getId_client();
		 this.id_abonnement = this.tblAbonnement.getSelectionModel().getSelectedItem().getId_abonnement(); 
		 this.id_revue = this.tblAbonnement.getSelectionModel().getSelectedItem().getId_revue(); 
		 this.jour_deb = this.tblAbonnement.getSelectionModel().getSelectedItem().getDate_debut().getDayOfMonth(); 
		 this.mois_deb = this.tblAbonnement.getSelectionModel().getSelectedItem().getDate_debut().getMonthValue();
		 this.annee_deb = this.tblAbonnement.getSelectionModel().getSelectedItem().getDate_debut().getYear(); 
		 this.jour_fin = this.tblAbonnement.getSelectionModel().getSelectedItem().getDate_fin().getDayOfMonth(); 
		 this.mois_fin = this.tblAbonnement.getSelectionModel().getSelectedItem().getDate_fin().getMonthValue();
		 this.annee_fin = this.tblAbonnement.getSelectionModel().getSelectedItem().getDate_fin().getYear(); 
		 Parent root;
		 java.net.URL url = new File("src/fxml/Modification_Abonnement.fxml").toURI().toURL();
		 root = FXMLLoader.load(url);
		
		 //FXMLLoader loader = new FXMLLoader(getClass().getResource("Modification_Abonnement.fxml")) ;
		 Scene scene = new Scene((root));
		 
		 primaryStage.setScene(scene);
		 primaryStage.setTitle("Modification d'un Abonnement");
		 primaryStage.setMaxWidth(700);
		 primaryStage.setMinWidth(700);
		 primaryStage.setMaxHeight(700);
		 primaryStage.setMinHeight(700);
		 primaryStage.show();
		 Stage stage = (Stage)this.btn_visualiser_abonnement.getScene().getWindow();
		 stage.close();
		 
	 }
	 
	 public void choix_visualiser_abonnement() throws Exception
	 {
		 this.id_client = this.tblAbonnement.getSelectionModel().getSelectedItem().getId_client();
		 this.id_abonnement = this.tblAbonnement.getSelectionModel().getSelectedItem().getId_abonnement(); 
		 this.id_revue = this.tblAbonnement.getSelectionModel().getSelectedItem().getId_revue(); 
		 this.jour_deb = this.tblAbonnement.getSelectionModel().getSelectedItem().getDate_debut().getDayOfMonth(); 
		 this.mois_deb = this.tblAbonnement.getSelectionModel().getSelectedItem().getDate_debut().getMonthValue();
		 this.annee_deb = this.tblAbonnement.getSelectionModel().getSelectedItem().getDate_debut().getYear(); 
		 this.jour_fin = this.tblAbonnement.getSelectionModel().getSelectedItem().getDate_fin().getDayOfMonth(); 
		 this.mois_fin = this.tblAbonnement.getSelectionModel().getSelectedItem().getDate_fin().getMonthValue();
		 this.annee_fin = this.tblAbonnement.getSelectionModel().getSelectedItem().getDate_fin().getYear(); 
		 Parent root;
		 java.net.URL url = new File("src/fxml/Visualisation_Abonnement.fxml").toURI().toURL();
		 root = FXMLLoader.load(url);
		
		 //FXMLLoader loader = new FXMLLoader(getClass().getResource("Visualisation_Abonnement.fxml")) ;
		 Scene scene = new Scene((root));
		 
		 primaryStage.setScene(scene);
		 primaryStage.setTitle("visualisation d'un Abonnement");
		 primaryStage.setMaxWidth(700);
		 primaryStage.setMinWidth(700);
		 primaryStage.setMaxHeight(700);
		 primaryStage.setMinHeight(700);
		 primaryStage.show();
		 Stage stage = (Stage)this.btn_visualiser_abonnement.getScene().getWindow();
		 stage.close();	
	 }
	 
	 public void choix_retour_abonnement() throws Exception
	 {
		 	java.net.URL url = new File("src/fxml/Metier.fxml").toURI().toURL();
			Parent root = FXMLLoader.load(url);
			Stage stage = (Stage)this.btn_retour_abonnement.getScene().getWindow();
			stage.setScene(new Scene(root, 700,700));
			stage.setTitle("Gestion des metiers");
			stage.setMaxWidth(700);
			stage.setMinWidth(700);
			stage.setMaxHeight(700);
			stage.setMinHeight(700);
	 }
	 
	 
}
