package controller;

import java.io.File;

import factory.DAOFactory;
import factory.Persistance;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import modele.metier.Periodicite;
import modele.metier.Revue;
import normalisation.NormalisationDescription;

public class Controller_Ajout_Revue 
{
	@FXML private Button btn_valider,btn_retour;
	@FXML private ComboBox cbx_periodicite ;
	@FXML private TextField text_titre,text_tarif,text_visuel;
	@FXML private TextArea text_description;
	@FXML private Label lbl_res;
	private Stage secondaryStage = new Stage();
	private DAOFactory dao = Controller_Menu_Persistence.dao;
	
	
	
	
	
	public void initialize() throws Exception
	{
		
		this.cbx_periodicite.setItems(FXCollections.observableArrayList(dao.getPeriodiciteDAO().findAll()));
		this.cbx_periodicite.setValue(dao.getPeriodiciteDAO().findAll().get(0));
		
	}
	public void choix_valider() throws Exception
	{
		String titre = this.text_titre.getText();
		String description = this.text_description.getText();
		Float tarif = Float.parseFloat(this.text_tarif.getText());
		String visuel = this.text_visuel.getText();
		Periodicite p1 =(Periodicite)cbx_periodicite.getValue();
		int periodicite = p1.getId_periodicite() ;
		
		Revue r1 = new Revue(titre, description, tarif, visuel, periodicite);
		if(NormalisationDescription.setDescriptionNormalise(r1)== true)
		{
			this.lbl_res.setText("La description est sup�rieur � 400 caract�res veuillez la resaisir!!");
		}
		else if(NormalisationDescription.setDescriptionNormalise(r1)== false)
		{
		
			dao.getRevueDAO().create(r1);
			FXMLLoader loader = new FXMLLoader() ;
			java.net.URL url = new File("src/fxml/Table_Revue.fxml").toURI().toURL();
			Parent root = FXMLLoader.load(url);
			Scene scene = new Scene(root);
			secondaryStage.setScene(scene);
			secondaryStage.setTitle("Gestion des Revue");
			secondaryStage.setMaxWidth(700);
			secondaryStage.setMinWidth(700);
			secondaryStage.setMaxHeight(700);
			secondaryStage.setMinHeight(700);
			secondaryStage.show();
			Stage stage = (Stage) btn_valider.getScene().getWindow();
			stage.close();
		}
	}
	
	public void choix_retour() throws Exception
	{
		FXMLLoader loader = new FXMLLoader() ;
		java.net.URL url = new File("src/fxml/Table_Revue.fxml").toURI().toURL();
		Parent root = FXMLLoader.load(url);
		Scene scene = new Scene(root);
		secondaryStage.setScene(scene);
		secondaryStage.setTitle("Gestion des Revue");
		secondaryStage.setMaxWidth(700);
		secondaryStage.setMinWidth(700);
		secondaryStage.setMaxHeight(700);
		secondaryStage.setMinHeight(700);
		secondaryStage.show();
		Stage stage = (Stage) btn_retour.getScene().getWindow();
		stage.close();
	}
	
		
		
	
}
