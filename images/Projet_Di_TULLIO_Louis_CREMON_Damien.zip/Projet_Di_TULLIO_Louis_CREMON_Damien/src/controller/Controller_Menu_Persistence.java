package controller;

import java.io.File;
import java.io.IOException;

import application.Main;
import factory.DAOFactory;
import factory.Persistance;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import modele.metier.Periodicite;

public class Controller_Menu_Persistence extends Main 
{
	
	@FXML private Button btn_retour_persistence;
	@FXML protected Button btn_mysql;
	@FXML protected Button btn_liste_memoire;

	@FXML private Button btn_fermer;
	@FXML private AnchorPane id_anchor;
	public static DAOFactory dao;

	public void choix_liste_memoire() throws Exception
	{
				java.net.URL url = new File("src/fxml/Metier.fxml").toURI().toURL();
				Parent root = FXMLLoader.load(url);
				Stage stage = (Stage)this.btn_liste_memoire.getScene().getWindow();
				stage.setScene(new Scene(root, 700,700));
				stage.setTitle("Gestion des metiers");
				stage.setMaxWidth(700);
				stage.setMinWidth(700);
				stage.setMaxHeight(700);
				stage.setMinHeight(700);
			this.dao =DAOFactory.getDAOFactory(Persistance.LISTE_MEMOIRE);


	}
	
	
	
	public void choix_mysql()throws Exception 
	{
		
		
		
		java.net.URL url = new File("src/fxml/Metier.fxml").toURI().toURL();
		Parent root = FXMLLoader.load(url);
		Stage stage = (Stage)this.btn_liste_memoire.getScene().getWindow();
		stage.setScene(new Scene(root, 700,700));
		stage.setTitle("Gestion des metiers");
		stage.setMaxWidth(700);
		stage.setMinWidth(700);
		stage.setMaxHeight(700);
		stage.setMinHeight(700);
		this.dao =DAOFactory.getDAOFactory(Persistance.MYSQL);
				
	}
	
	
	
	
	
	public void choix_retour_persistence() throws Exception
	{
		java.net.URL url = new File("src/fxml/Accueil.fxml").toURI().toURL();
		Parent root = FXMLLoader.load(url);
		Stage stage = (Stage)this.btn_retour_persistence.getScene().getWindow();
		stage.setScene(new Scene(root, 700,700));
		stage.setTitle("Accueil");
		stage.setMaxWidth(700);
		stage.setMinWidth(700);
		stage.setMaxHeight(700);
		stage.setMinHeight(700);
	
	}
	

	
	
	
	

	
	
	
	
	
		
	
	
	
	
	
}

