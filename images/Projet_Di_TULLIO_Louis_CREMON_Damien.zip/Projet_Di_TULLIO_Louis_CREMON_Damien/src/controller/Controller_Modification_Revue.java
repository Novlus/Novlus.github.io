package controller;

import java.io.File;

import factory.DAOFactory;
import factory.Persistance;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import modele.metier.Periodicite;
import modele.metier.Revue;
import normalisation.NormalisationDescription;

public class Controller_Modification_Revue extends Controller_Menu_Persistence
{

	private int id_revue = Controller_Table_Revue.id_revue2;
	@FXML
	private TextField text_id_revue,text_titre,text_tarif,text_visuel;
	@FXML private TextArea text_description;
	@FXML private ComboBox cbx_periodicite;
	@FXML private Label lbl_res;
	
	private DAOFactory dao = Controller_Menu_Persistence.dao;
	
	@FXML
	private Button btn_modifier,btn_retour;
	
	
	public void initialize() throws Exception
	{
		this.cbx_periodicite.setValue(dao.getPeriodiciteDAO().getById(Controller_Table_Revue.id_periodicite2));
		this.cbx_periodicite.setItems(FXCollections.observableArrayList(dao.getPeriodiciteDAO().findAll()));
		this.text_titre.setText(String.valueOf(Controller_Table_Revue.titre2));
		this.text_tarif.setText(String.valueOf(Controller_Table_Revue.tarif2));
		this.text_description.setText(String.valueOf(Controller_Table_Revue.description2));
		this.text_visuel.setText(String.valueOf(Controller_Table_Revue.visuel2));
		
		
		
	}
	
	public void choix_modifier() throws Exception
	{
		Revue r1 = new Revue(this.id_revue,this.text_titre.getText(),this.text_description.getText(),Float.parseFloat(this.text_tarif.getText()),this.text_visuel.getText(),((Periodicite)this.cbx_periodicite.getSelectionModel().getSelectedItem()).getId_periodicite());
		if(NormalisationDescription.setDescriptionNormalise(r1)== true)
		{
			this.lbl_res.setText("La description est sup�rieur � 400 caract�res veuillez la resaisir!!");
		}
		else if(NormalisationDescription.setDescriptionNormalise(r1)== false)
		{
		this.dao.getRevueDAO().update(r1);
		Stage secondaryStage = new Stage();
		FXMLLoader loader = new FXMLLoader() ;
		java.net.URL url = new File("src/fxml/Table_Revue.fxml").toURI().toURL();
		Parent root = FXMLLoader.load(url);
		Scene scene = new Scene(root);
		secondaryStage.setScene(scene);
		secondaryStage.setTitle("Gestion des Revues");
		secondaryStage.setMaxWidth(700);
		secondaryStage.setMinWidth(700);
		secondaryStage.setMaxHeight(700);
		secondaryStage.setMinHeight(700);
		secondaryStage.show();
		Stage stage = (Stage) this.btn_modifier.getScene().getWindow();
		stage.close();
		}
		
	}
	
	public void choix_retour() throws Exception
	{
		Stage secondaryStage = new Stage();
		FXMLLoader loader = new FXMLLoader() ;
		java.net.URL url = new File("src/fxml/Table_Revue.fxml").toURI().toURL();
		Parent root = FXMLLoader.load(url);
		Scene scene = new Scene(root);
		secondaryStage.setScene(scene);
		secondaryStage.setTitle("Gestion des Revues");
		secondaryStage.setMaxWidth(700);
		secondaryStage.setMinWidth(700);
		secondaryStage.setMaxHeight(700);
		secondaryStage.setMinHeight(700);
		secondaryStage.show();
		Stage stage = (Stage) this.btn_retour.getScene().getWindow();
		stage.close();
	}
	
}
