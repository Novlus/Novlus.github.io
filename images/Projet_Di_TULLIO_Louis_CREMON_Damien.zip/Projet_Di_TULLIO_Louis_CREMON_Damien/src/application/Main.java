package application;
	
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import modele.metier.Revue;


public class Main extends Application {
	@FXML
	Button btn_Persistence;
	protected Stage primaryStage = new Stage();
	@Override
	public void start(Stage primaryStage) throws Exception
		{
		
			FXMLLoader loader = new FXMLLoader() ;
			java.net.URL url = new File("src/fxml/Accueil.fxml").toURI().toURL();
			Parent root = FXMLLoader.load(url);
			Scene scene = new Scene(root);
			primaryStage.setScene(scene);
			primaryStage.setTitle("Accueil");
			primaryStage.setMaxWidth(700);
			primaryStage.setMinWidth(700);
			primaryStage.setMaxHeight(550);
			primaryStage.setMinHeight(550);
			primaryStage.show();
			this.primaryStage = primaryStage ;
		
		}

	public static void main(String[] args) throws IOException {
		
		launch(args);
	}
}
