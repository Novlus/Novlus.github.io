package csv;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import controller.Controller_Menu_Persistence;
import controller.Controller_Table_Client;
import factory.DAOFactory;
import factory.Persistance;
import modele.metier.Client;

public class ImportCSV 
{
	public static void main(String[] args) throws IOException {
		String path = "C:/Users/Damien/Desktop/document/client.csv";
		BufferedReader br;
		String line = "";
		String[] values = null ;
		try {
			br = new BufferedReader (new FileReader(path));
			while ((line = br.readLine())!= null)
			{
				values = line.split(";");
				System.out.println(values[0]);
				Client cl1 = new Client (values[0],values[1],values[2],values[3],values[4],values[5],values[6]);
				Controller_Table_Client.Normalise(cl1);
				DAOFactory.getDAOFactory(Persistance.MYSQL).getClientDAO().create(cl1);
				
			}
			
			
			
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
			
		{
			System.out.println(line);
		}
		
	}
}

