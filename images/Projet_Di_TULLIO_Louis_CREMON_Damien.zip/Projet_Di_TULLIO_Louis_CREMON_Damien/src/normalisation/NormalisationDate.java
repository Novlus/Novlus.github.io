package normalisation;

import modele.metier.Abonnement;

public class NormalisationDate 
{
	public static boolean setDateNormalise(Abonnement a1)
	{
		boolean res = false;
		//if (a1.getDate_debut().getMonthValue()>a1.getDate_fin().getMonthValue() && a1.getDate_debut().getDayOfMonth()>a1.getDate_fin().getDayOfMonth())
		//{
		//	res = true;
		//}
		if(a1.getDate_debut().getDayOfMonth()>a1.getDate_fin().getDayOfMonth()&&a1.getDate_debut().getMonthValue()>=a1.getDate_fin().getMonthValue()&& a1.getDate_debut().getYear()>=a1.getDate_fin().getYear())
		{
			res = true;
		}
		
		else if(a1.getDate_debut().getMonthValue()>a1.getDate_fin().getMonthValue()&& a1.getDate_debut().getYear()>=a1.getDate_fin().getYear())
		{
			res = true;
		}
		
		else if(a1.getDate_debut().getYear()>a1.getDate_fin().getYear())
		{
			res = true;
		}
		
		return res;
	}
}
