package normalisation;

import modele.metier.Revue;

public class NormalisationDescription 
{
	public static boolean setDescriptionNormalise(Revue r1)
	{
		boolean resultat = false;
		if (r1.getDescription().length()>400)
		{
			resultat = true;
		}
		return resultat ;
	}
}
