package normalisation;

import factory.DAOFactory;
import factory.Persistance;
import modele.metier.Client;

public class NormalisationDoublonClient 
{
	
	public static boolean setDoublonNormalise(Client cl1,DAOFactory dao) throws Exception
	{
		boolean res = false;
		if (dao.getClientDAO().findAll().contains(cl1)== true)
		{
			res = true;
		}
		else if (dao.getClientDAO().findAll().contains(cl1)== true)
		{
			res = true;
		}
		
		return res;
	}

}
