package factory;

public enum Persistance 
{
	MYSQL,LISTE_MEMOIRE;
}
