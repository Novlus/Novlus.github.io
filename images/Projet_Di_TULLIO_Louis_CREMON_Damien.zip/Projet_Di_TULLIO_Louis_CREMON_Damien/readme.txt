voici la liste des differents élements.

Nous avons un menu qui permet de choisir la persistence que l'on souhaite.

On peut saisir  le titre d'une revue, sa description( qui n'est pas supérieur à 400 caractères grace à une verification de cette derniere),le prix au numéro et la périodicité d'une revue

On peut saisir  les différentes Périodicités possibles

On peut saisir les clients (numéro,nom,prénom,adresse compléte) avec normalisation de ces derniers.

On peut saisir un abonnement(client,revue,date de début et de fin d'abonnement) avec verification des date(la date de debut ne doit pas etre superieur à celle de fin).

On peut modifier/supprimer/visualier une periodicité,un abonnement,une revue, un client

Ces dernier apparaissent dans une table.

probléme avec le bouton d'ajout qui ce réactive si on change d'item dans la table.

sinon les autres boutons fonctionnent correctement.

il n'y a pas de vérification de doublon

il n'y a pas de visuel pour la revue (image de couverture) à la place il y a un visuel String (neuf,abimés,etc...)

l'import de fichier CSV ne fonctionne pas on arrive seulement à les lires.


Répartitition des tâches:

Louis :
POJO (Client,Abonnement,Periodicite,Revue)
normalisation
test normalisation
Controller Visualisation
Controller Menu

Damien :
Connexion
DAO
partie graphique (scene builder)
Controller Table,modification et ajout
application.Main (qui permet de lancer le programme)
import csv (non fonctionnelle)





Investissement de chacun en pourcentage : 
	DI TULLIO Louis 40%
	
	CREMON Damien 60% 